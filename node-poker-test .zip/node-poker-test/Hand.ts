type cardColor = 'H' | 'C' | 'S' | 'D';
type cardValue = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K' | 'A';
type handName = 'Straight flush' | 'Four of a kind' | 'Full house' | 'Flush' | 'Straight' | 'Three of a kind' | 'Two pair' | 'One pair' | 'High card';

export class Hand {
  rankArray: any[] = [];
  suitArray: any[] = [];
  handType: handName;

  suits = ["C", "D", "H", "S"];
  ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

  constructor(input: string) {
    let arrayHandOne = input.split(",");

    const sorted = (arrayHand: string | any[]) => {
      let sortedHand = [];
      for (let i = 0; i < this.ranks.length; i++) {
        for (let j = 0; j < arrayHand.length; j++) {
          if (this.ranks[i] === arrayHand[j].charAt(0)) {
            sortedHand.push(arrayHand[j]);
          }
        }
      }
      return sortedHand;
    };

    let sortedHandOne = sorted(arrayHandOne);
    const suitAndRank = (sortedHand: string | any[]) => {
      for (let i = 0; i < sortedHand.length; i++) {
        this.rankArray.push(sortedHand[i].charAt(0));
        this.suitArray.push(sortedHand[i].charAt(1));
      }
    };

    suitAndRank(sortedHandOne);

    function countSuites(suitArray: any[]) {
      let suitCount: any = {};
      suitArray.forEach(function (x: any) {
        suitCount[x] = (suitCount[x] || 0) + 1;
      });
      return suitCount;
    }

    function countRanks(rankArray: any[]) {
      let rankCount: any = {};
      rankArray.forEach(function (x: string) {
        rankCount[x] = (rankCount[x] || 0) + 1;
      });
      return rankCount;
    }

    const isFlush = () => {
      let cS = countSuites(this.suitArray);
      if (Object.keys(cS).find((key) => cS[key] === 5)) {
        return true;
      } else {
        return false;
      }
    };

    const isStraight = () => {
      let index = this.ranks.indexOf(this.rankArray[0]);
      let ref = this.ranks.slice(index, index + 5).join("");
      let section = this.rankArray.slice(0).join("");
      if (section === "10JQKA" && section === ref) {
        return "ROYALSTRAIGHT";
      } else if (section === "A2345" || section === ref) {
        return "STRAIGHT";
      } else {
        return "FALSE";
      }
    };

    const pairs = () => {
      let rS = countRanks(this.rankArray);
      return Object.keys(rS).filter((key) => rS[key] === 2).length;
    };

    const whichHand = (): handName => {
      let rS = countRanks(this.rankArray);
      if (isFlush() === true && isStraight() === "STRAIGHT") {
        return "Straight flush";
      } else if (Object.keys(rS).find((key) => rS[key] === 4)) {
        return "Four of a kind";
      } else if (
        Object.keys(rS).find((key) => rS[key] === 3) &&
        pairs() === 2
      ) {
        return "Full house";
      } else if (isFlush() === true) {
        return "Flush";
      } else if (isStraight() === "STRAIGHT") {
        return "Straight";
      } else if (Object.keys(rS).find((key) => rS[key] === 3)) {
        return "Three of a kind";
      } else if (pairs() === 2) {
        return "Two pair";
      } else if (pairs() === 1) {
        return "One pair";
      } else {
        return "High card";
      }
    };

    this.handType = whichHand();
  }

  winsOver(otherHand: Hand): boolean {
    // YOUR CODE HERE
    if (this.handType == "High card" && otherHand.handType == "High card") {
      return (
        valueOfCard(this.rankArray[this.rankArray.length - 1]) >
        valueOfCard(otherHand.rankArray[otherHand.rankArray.length - 1])
      );
    } else if (otherHand.handType == "High card") {
      return valueOfHand(this.handType) < valueOfHand(otherHand.handType);
    }
    return valueOfHand(this.handType) > valueOfHand(otherHand.handType);
  }
}


function valueOfHand(name: handName) : number{
  switch(name){
    case "High card":       return 0;
    case "One pair":        return 1;
    case "Two pair":        return 2;
    case "Three of a kind": return 3;
    case "Straight":        return 4;
    case "Flush":           return 5;
    case "Full house":      return 6;
    case "Four of a kind":  return 7;
    case "Straight flush":  return 8;
    default:                return 0;
  }
}

function valueOfCard(name: cardValue) : number{
  switch(name){
    case "2": return 0;
    case "3": return 1;
    case "4": return 2;
    case "5": return 3;
    case "6": return 4;
    case "7": return 5;
    case "8": return 6;
    case "9": return 7;
    case "10":return 8;
    case "J": return 9;
    case "Q": return 10;
    case "K": return 11;
    case "A": return 12;
    default:  return 0;
  }
}